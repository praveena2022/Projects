import { Component } from '@angular/core';

@Component({
  selector: 'app-client-info',
  templateUrl: './client-info.component.html',
  styleUrls: ['./client-info.component.css']
})
export class ClientInfoComponent {
  clients = [
    { name: 'Client A', projects: 3, tasksCompleted: 15, effort: '120h' },
    { name: 'Client B', projects: 5, tasksCompleted: 25, effort: '200h' }
  ];


  constructor() { }
  
}
