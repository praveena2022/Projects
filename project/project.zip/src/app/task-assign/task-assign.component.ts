import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ProjectService } from '../project.service.service';
import { Project, Task, TeamMember } from '../project';

@Component({
  selector: 'app-task-assign',
  templateUrl: './task-assign.component.html',
  styleUrls: ['./task-assign.component.css']
})
export class TaskAssignComponent implements OnInit {
  showForm = false;
  project: Project | undefined;
  selectedProjectId: number | undefined; 

  newTask: Task = { id: 0, name: '', description: '', assignedTo: 0 };

  constructor(
    private route: ActivatedRoute,
    private projectService: ProjectService
  ) {}

  toggleFormVisibility(): void {
    this.showForm = !this.showForm;
  }
  
  onProjectSelectChange(): void {
    this.showForm = true; // Show the form when a project is selected
  }

  ngOnInit(): void {
    const projectId = Number(this.route.snapshot.paramMap.get('id'));
    this.projectService.getProjectById(projectId).subscribe((project) => {
      this.project = project;
    });
  }

  createTask(): void {
    if (this.project) {
      this.projectService.addTaskToProject(this.project.id, this.newTask).subscribe(() => {
        this.newTask = { id: 0, name: '', description: '', assignedTo: 0 };
        // Refresh the project data after creating the task
        this.projectService.getProjectById(this.project!.id).subscribe((project) => {
          this.project = project;
        });
      });
    }
  }

  getMemberName(memberId: number): string {
    const member = this.project?.teamMembers.find(m => m.id === memberId);
    return member ? member.name : 'Unknown';
  }
}
