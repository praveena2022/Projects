import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { Project, Task, TeamMember } from './project'; // Adjust the path as needed

@Injectable({
  providedIn: 'root'
})
export class ProjectService {
  private projects: Project[] = [
    {
      id: 1,
      name: 'Project 1',
      description: 'Description for Project 1',
      clientName: 'Client A',
      teamMembers: [
        { id: 1, name: 'John Doe', role: 'Developer' },
        { id: 2, name: 'Jane Smith', role: 'Tester' }
      ],
      tasks: [
        { id: 1, name: 'Task 1', description: 'Task 1 description', assignedTo: 1 },
        { id: 2, name: 'Task 2', description: 'Task 2 description', assignedTo: 2 }
      ],
      dueDate: new Date(),
      assignedDate: new Date()
    },
    {
      id: 0,
      name: 'Project 0',
      description: 'Description for Project 0',
      clientName: 'Client B',
      teamMembers: [
        { id: 1, name: 'Jb Doe', role: 'Developer' },
        { id: 2, name: 'Jane Smith', role: 'Tester' }
      ],
      tasks: [
        { id: 1, name: 'Task 1', description: 'Task 1 description', assignedTo: 1 },
        { id: 2, name: 'Task 2', description: 'Task 2 description', assignedTo: 2 }
      ],
      dueDate: new Date(),
      assignedDate: new Date()
    }
  ];

  constructor() {}

  getProjects(): Observable<Project[]> {
    return of(this.projects);
  }

  getProjectById(id: number): Observable<Project | undefined> {
    return of(this.projects.find(project => project.id === id));
  }

  addTaskToProject(projectId: number, task: Task): Observable<void> {
    const project = this.projects.find(p => p.id === projectId);
    if (project) {
      task.id = project.tasks.length + 1;
      project.tasks.push(task);
    }
    return of();
  }
}
