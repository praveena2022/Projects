// src/app/projects/projects.component.ts
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProjectService } from '../project.service.service'; // Adjust the path as needed
import { Project } from '../project'; // Ensure this path is correct

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent implements OnInit {
  projects: Project[] = [];

  constructor(private projectService: ProjectService, private router: Router) {}

  ngOnInit(): void {
    this.projectService.getProjects().subscribe((projects: Project[]) => {
      this.projects = projects;
    });
  }

  viewProjectDetails(projectId: number): void {
    this.router.navigate([`/project-manager/projects/${projectId}`]);
  }

  viewTaskAssign(projectId: number): void {
    this.router.navigate([`/project-manager/projects/${projectId}/task-assign`]);
  }
}
